package interfaces;
import java.lang.*;
import classes.*;
public interface ITransactions		//common example of an interface
{
	void buyAnItem(int amount);			//we can just mention/declare methods
	void addMoney(int amount);
}